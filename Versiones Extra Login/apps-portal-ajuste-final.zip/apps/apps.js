const appCards = document.querySelectorAll('.app-card');
const appsSearch = document.getElementById('appsSearch');
const appCategories = document.querySelectorAll('.apps-category');

appCards.forEach((card) => {
  card.addEventListener('click', function () {
    card.classList.add('is-selected');
    window.setTimeout(() => card.classList.remove('is-selected'), 450);
  });
});

if (appsSearch) {
  appsSearch.addEventListener('input', function () {
    const query = appsSearch.value.trim().toLowerCase();

    appCategories.forEach((category) => {
      const cards = category.querySelectorAll('.app-card');
      let visibleCount = 0;

      cards.forEach((card) => {
        const haystack = (card.dataset.search || card.dataset.app || '').toLowerCase();
        const matches = haystack.includes(query);
        card.hidden = !matches;

        if (matches) {
          visibleCount += 1;
        }
      });

      category.classList.toggle('is-empty', visibleCount === 0);
    });
  });
}
